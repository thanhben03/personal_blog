<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                2018 - 2020 © Hyper - Coderthemes.com
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-md-block">
                    <a href="javascript: void(0);">About</a>
                    <a href="javascript: void(0);">Support</a>
                    <a href="javascript: void(0);">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- end demo js-->

<!-- end Footer -->

</div> <!-- content-page -->

</div> <!-- end wrapper-->
</div>
<!-- END Container -->

<!-- /Right-bar -->


<!-- bundle -->

<script src="<?= $helper->base_url('public/admin/js/vendor.min.js') ?>"></script>
<script src="<?= $helper->base_url('public/admin/js/app.min.js') ?>"></script>

<!-- third party js -->
<script src="<?= $helper->base_url('public/admin/js/apexcharts.min.js') ?>"></script>
<script src="<?= $helper->base_url('public/admin/js/jquery-jvectormap-1.2.2.min.js') ?>"></script>
<script src="<?= $helper->base_url('public/admin/js/jquery-jvectormap-world-mill-en.js') ?>"></script>
<!-- third party js ends -->

<!-- demo app -->
<script src="<?= $helper->base_url('public/admin/js/demo.dashboard.js') ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
<script src="https://cdn.tiny.cloud/1/j7s71fyc3kax1nrnlchfbs12d0rgzpsuwjdnkn43xugf4xgv/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</body>

</html>